<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manik Html 5 Project // About</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <!-- header section start -->
    <header class="main-header">
        <div class="inner-header">
            <div class="logo-area">
                <a href=""><img class="logo-1" src="images/logo.png" alt="Logo" title="Logo"></a>
                <a href=""><img class="logo-2" src="images/logo-2.png" alt="Logo" title="Logo"></a>
            </div>
            <div class="main-menu">
                <div class="inner-menu">
                    <ul class="menu-list">
                        <li class="menu-itam"><a href="index.php"><i class="fa fa-home"></i>Home</a></li>
                        <li class="menu-itam active"><a href="about.php"><i class="fa fa-street-view"></i>About</a></li>
                        <li class="menu-itam"><a href="portfolio.php"><i class="fa fa-file-code-o"></i>portfolio</a></li>
                        <li class="menu-itam"><a href=""><i class="fa fa-sort-alpha-desc"></i>Faq</a></li>
                        <li class="menu-itam"><a href=""><i class="fa fa-id-card"></i>contact</a></li>
                    </ul>
                </div>
            </div>
            <div class="social-icon">
                <ul class="list-style-one">
                    <li><a href=""><i class="fa fa-facebook"></i></a></li>
                    <li><a href=""><i class="fa fa-twitter"></i></a></li>
                    <li><a href=""><i class="fa fa-google-plus"></i></a></li>
                    <li><a href=""><i class="fa fa-linkedin"></i></a></li>
                    <li><a href=""><i class="fa fa-skype"></i></a></li>
                </ul>
            </div>
        </div>
    </header>
    <!-- header section end -->

    <div class="container">
        <!-- About section start -->
        <section class="about">
            <div class="section-title">
                <h2 class="title">About me</h2>
                <span class="bg-text">Resume</span>
            </div>
            <div class="containet">
                <div class="inner_row">
                    <div class="personal-infos">
                        <h4 class="title">personal infos</h4>
                        <div class="list-style-one">
                            <ul>
                                <li>first name: <span>Mahmud Hasan</span></li>
                                <li>Age: <span>20 Years</span></li>
                                <li>Freelance: <span>Available</span></li>
                                <li>phone: <span>0123456789</span></li>
                                <li>Skype: <span>mahmud.hasan</span></li>
                            </ul>
                            <ul>
                                <li>last name: <span>Manik</span></li>
                                <li>Nationality: <span>bangladesh</span></li>
                                <li>Address: <span>bangladesh</span></li>
                                <li>Email: <span>hasan@gmail.com</span></li>
                                <li>langages: <span>Bangla, English</span></li>
                            </ul>
                        </div>
                        <a class="btn-style-one" href="about.php">Download CV <i class="fa fa-download"></i></a>
                    </div>
                    <div class="experience">
                        <div class="inner-experience">
                            <div class="experience-box">
                                <h2 class="number">12</h2>
                                <p class="text">years of <br>experience</p>
                            </div>
                            <div class="experience-box">
                                <h2 class="number">97</h2>
                                <p class="text">completed<br>projects</p>
                            </div>
                            <div class="experience-box">
                                <h2 class="number">81</h2>
                                <p class="text">Happy<br>customers</p>
                            </div>
                            <div class="experience-box">
                                <h2 class="number">53</h2>
                                <p class="text">awards<br>won</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>        
        <!-- About section end -->

        <!-- Education section start -->
         <section class="education-section">
            <h2 class="section-title">Experience Education</h2>
            <div class="continer">
                <div class="inner_row">
                    <div class="box">
                        <div class="education-box">
                            <div class="icon">
                                <i class="fa fa-briefcase"></i>
                            </div>
                            <div class="contant">
                                <span class="time">2018 - Present</span>
                                <h4 class="title"> Web Developer <span>Envato</span></h4>
                                <p class="text">Lorem ipsum dolor sit amet, consectetur tempor incididunt ut labore adipisicing elit</p>
                            </div>
                        </div>
                        <div class="education-box">
                            <div class="icon">
                                <i class="fa fa-briefcase"></i>
                            </div>
                            <div class="contant">
                                <span class="time">2015</span>
                                <h4 class="title"> ENGINEERING DEGREE <span>OXFORD UNIVERSITY</span></h4>
                                <p class="text">Lorem ipsum dolor sit amet, consectetur tempor incididunt ut labore adipisicing elit</p>
                            </div>
                        </div>
                    </div>
                    <div class="box">
                        <div class="education-box">
                            <div class="icon">
                                <i class="fa fa-briefcase"></i>
                            </div>
                            <div class="contant">
                                <span class="time">2013 - 2018</span>
                                <h4 class="title"> UI/UX Designer <span>Themeforest</span></h4>
                                <p class="text">Lorem incididunt dolor sit amet, consectetur eiusmod dunt doldunt dol elit, tempor incididunt</p>
                            </div>
                        </div>
                        <div class="education-box">
                            <div class="icon">
                                <i class="fa fa-briefcase"></i>
                            </div>
                            <div class="contant">
                                <span class="time">2012</span>
                                <h4 class="title"> MASTER DEGREE <span>KIEV UNIVERSITY</span></h4>
                                <p class="text">Lorem incididunt dolor sit amet, consectetur eiusmod dunt doldunt dol elit, tempor incididunt</p>
                            </div>
                        </div>
                    </div>
                    <div class="box">
                        <div class="education-box">
                            <div class="icon">
                                <i class="fa fa-briefcase"></i>
                            </div>
                            <div class="contant">
                                <span class="time">2005 - 2013</span>
                                <h4 class="title"> Consultant <span>Videohive</span></h4>
                                <p class="text">Lorem ipsum dolor sit amet, tempor incididunt ut laboreconsectetur elit, sed do eiusmod tempor duntt</p>
                            </div>
                        </div>
                        <div class="education-box">
                            <div class="icon">
                                <i class="fa fa-briefcase"></i>
                            </div>
                            <div class="contant">
                                <span class="time">2009</span>
                                <h4 class="title"> BACHELOR DEGREE <span>TUNIS HIGH SCHOOL</span></h4>
                                <p class="text">Lorem ipsum dolor sit amet, tempor incididunt ut laboreconsectetur elit, sed do eiusmod tempor duntt</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
         </section>
        <!-- Education section end -->      
    </div>
    
    <script src="js/apps.js"></script>
</body>
</html>