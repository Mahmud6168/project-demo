<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manik Html 5 Project // Home</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <!-- header section start -->
    <header class="main-header">
        <div class="inner-header">
            <div class="logo-area">
                <a href=""><img class="logo-1" src="images/logo.png" alt="Logo" title="Logo"></a>
                <a href=""><img class="logo-2" src="images/logo-2.png" alt="Logo" title="Logo"></a>
            </div>
            <div class="main-menu">
                <div class="inner-menu">
                    <ul class="menu-list">
                        <li class="menu-itam active"><a href="index.php"><i class="fa fa-home"></i>Home</a></li>
                        <li class="menu-itam"><a href="about.php"><i class="fa fa-street-view"></i>About</a></li>
                        <li class="menu-itam"><a href="portfolio.php"><i class="fa fa-file-code-o"></i>portfolio</a></li>
                        <li class="menu-itam"><a href=""><i class="fa fa-sort-alpha-desc"></i>Faq</a></li>
                        <li class="menu-itam"><a href=""><i class="fa fa-id-card"></i>contact</a></li>
                    </ul>
                </div>
            </div>
            <div class="social-icon">
                <ul class="list-style-one">
                    <li><a href=""><i class="fa fa-facebook"></i></a></li>
                    <li><a href=""><i class="fa fa-twitter"></i></a></li>
                    <li><a href=""><i class="fa fa-google-plus"></i></a></li>
                    <li><a href=""><i class="fa fa-linkedin"></i></a></li>
                    <li><a href=""><i class="fa fa-skype"></i></a></li>
                </ul>
            </div>
        </div>
    </header>
    <!-- header section end -->

     <div class="container">
        <!-- Banner section start -->
        <section class="banner">
            <div class="inner_container">
                <div class="bgColor"></div>
                <div class="inner_row">
                    <div class="content">
                        <span class="sub-title">Hello I’m</span>
                        <h1 class="title">Mahmud <br>Hasan <span>Manik</span></h1>
                        <h4>A Passionate <span>web designer</span></h4>
                        <a class="btn-style-one" href="about.php">more about me <i class="fa fa-arrow-right"></i></a>
                    </div>
                    <div class="img-box">
                        <img src="images/main.jpg" alt="">
                    </div>
                </div>
            </div>
        </section>
        <!-- Banner section end -->
     </div>

    
    <script src="js/apps.js"></script>
</body>
</html>