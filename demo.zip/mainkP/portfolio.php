<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manik Html 5 Project // Portfolio</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <!-- header section start -->
    <header class="main-header">
        <div class="inner-header">
            <div class="logo-area">
                <a href=""><img class="logo-1" src="images/logo.png" alt="Logo" title="Logo"></a>
                <a href=""><img class="logo-2" src="images/logo-2.png" alt="Logo" title="Logo"></a>
            </div>
            <div class="main-menu">
                <div class="inner-menu">
                    <ul class="menu-list">
                        <li class="menu-itam"><a href="index.php"><i class="fa fa-home"></i>Home</a></li>
                        <li class="menu-itam"><a href="about.php"><i class="fa fa-street-view"></i>About</a></li>
                        <li class="menu-itam active"><a href="portfolio.php"><i class="fa fa-file-code-o"></i>portfolio</a></li>
                        <li class="menu-itam"><a href=""><i class="fa fa-sort-alpha-desc"></i>Faq</a></li>
                        <li class="menu-itam"><a href=""><i class="fa fa-id-card"></i>contact</a></li>
                    </ul>
                </div>
            </div>
            <div class="social-icon">
                <ul class="list-style-one">
                    <li><a href=""><i class="fa fa-facebook"></i></a></li>
                    <li><a href=""><i class="fa fa-twitter"></i></a></li>
                    <li><a href=""><i class="fa fa-google-plus"></i></a></li>
                    <li><a href=""><i class="fa fa-linkedin"></i></a></li>
                    <li><a href=""><i class="fa fa-skype"></i></a></li>
                </ul>
            </div>
        </div>
    </header>
    <!-- header section end -->

     <div class="container">
        <!-- Portfolio section start -->
        <section class="portfolio-section">
            <div class="section-title">
                <h2 class="title">my portfolio</h2>
                <span class="bg-text">works</span>
            </div>
            <div class="container">
                <div class="inner_row">
                    <div class="portfolio-item">
                        <div class="inner">
                            <div class="img-box">
                                <a href="portfolio.php"><img src="images/portfolio-1.jpg" alt=""></a>
                            </div>
                            <h6 class="title">MOCKUP PROJECT</h6>
                        </div>
                    </div>
                    <div class="portfolio-item">
                        <div class="inner">
                            <div class="img-box">
                                <a href="portfolio.php"><img src="images/portfolio-2.jpg" alt=""></a>
                            </div>
                            <h6 class="title">MOCKUP PROJECT</h6>
                        </div>
                    </div>
                    <div class="portfolio-item">
                        <div class="inner">
                            <div class="img-box">
                                <a href="portfolio.php"><img src="images/portfolio-3.jpg" alt=""></a>
                            </div>
                            <h6 class="title">MOCKUP PROJECT</h6>
                        </div>
                    </div>
                    <div class="portfolio-item">
                        <div class="inner">
                            <div class="img-box">
                                <a href="portfolio.php"><img src="images/portfolio-4.jpg" alt=""></a>
                            </div>
                            <h6 class="title">MOCKUP PROJECT</h6>
                        </div>
                    </div>
                    <div class="portfolio-item">
                        <div class="inner">
                            <div class="img-box">
                                <a href="portfolio.php"><img src="images/portfolio-5.jpg" alt=""></a>
                            </div>
                            <h6 class="title">MOCKUP PROJECT</h6>
                        </div>
                    </div>
                    <div class="portfolio-item">
                        <div class="inner">
                            <div class="img-box">
                                <a href="portfolio.php"><img src="images/portfolio-6.jpg" alt=""></a>
                            </div>
                            <h6 class="title">MOCKUP PROJECT</h6>
                        </div>
                    </div>
                    <div class="portfolio-item">
                        <div class="inner">
                            <div class="img-box">
                                <a href="portfolio.php"><img src="images/portfolio-7.jpg" alt=""></a>
                            </div>
                            <h6 class="title">MOCKUP PROJECT</h6>
                        </div>
                    </div>
                    <div class="portfolio-item">
                        <div class="inner">
                            <div class="img-box">
                                <a href="portfolio.php"><img src="images/portfolio-8.jpg" alt=""></a>
                            </div>
                            <h6 class="title">MOCKUP PROJECT</h6>
                        </div>
                    </div>
                    <div class="portfolio-item">
                        <div class="inner">
                            <div class="img-box">
                                <a href="portfolio.php"><img src="images/portfolio-9.jpg" alt=""></a>
                            </div>
                            <h6 class="title">MOCKUP PROJECT</h6>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Portfolio section end -->
     </div>

    
    <script src="js/apps.js"></script>
</body>
</html>